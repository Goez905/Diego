const express = require('express');
const app = express();
const port = 3000;
const bodyParser = require('body-parser');
app.use(bodyParser.json()); // body parse es un middleware que nos permite acceder al cuerpo de la petición
const ventas = [
    {
        id: 1,
        numCheck: 'FAC001',
        numUnit: 10,
        clientName: 'Juana de Arco',
        value: 500
    },
    {
        id: 2,
        numCheck: 'FAC002',
        numUnit: 5,
        clientName: 'Policarpa Salavarrieta',
        value: 250
    },
    {
        id: 3,
        numCheck: 'FAC003',
        numUnit: 20,
        clientName: 'Tutankamon',
        value: 1000
    },
    {
        id: 4,
        numCheck: 'FAC004',
        numUnit: 7,
        clientName: 'Sócrates',
        value: 350
    },
    {
        id: 5,
        numCheck: 'FAC005',
        numUnit: 12,
        clientName: 'Simón Bolivar',
        value: 600
    }
];

//2.	Crear en node el método get que calcule y retorne en json la suma total de número de unidades facturadas.

app.get('/unidades', (req, res) => {
    let suma = 0;
    ventas.forEach(element => {
        suma += element.numUnit;
    });
    res.json({ suma }); // retorna la suma de las unidades en json
    console.log(suma);
}
);

//3.	Crear en node el método get que calcule y retorne en json el valor total facturado.
app.get('/total', (req, res) => {
    let suma = 0;
    ventas.forEach(element => {
        suma += element.value * element.numUnit;
    });
    res.json({ suma });
    console.log(suma);
}
);

//4.	Crear en node el método get que retorne los datos de una factura de venta de acuerdo al id a consultar
app.get('/ventas/:id', (req, res) => {
    const id = req.params.id;
    const venta = ventas.find(element => element.id == id);
    res.json(venta);
}
);
//5. Crear en node el método get que retorne en un json el id de la factura con el nombre del cliente de todas las facturas.

app.post('/ventas', (req, res) => {
    const { id, numCheck, numUnit, clientName, value } = req.body; // destructuración de objetos
    const newVenta = {
        id,
        numCheck,
        numUnit,
        clientName,
        value
    };
    ventas.push(newVenta);
    res.json(newVenta);
})

//6.	Crear el método para insertar facturas en el array siguiendo la misma estructura de los objetos del ejemplo.
app.post('/ventas', (req, res) => {
    const { id, numCheck, numUnit, clientName, value } = req.body;
    const newVenta = { id, numCheck, numUnit, clientName, value };
    ventas.push(newVenta);
    res.status(201).json(newVenta);
});
//7.	Crear el método put que permita realizar al usuario un decremento entre un 1 y 10% al valor total de todas las facturas. El % lo debe enviar al testear la api.
app.put('/ventas/decrementar', (req, res) => {
    const { percentage } = req.body;
    if (percentage < 1 || percentage > 10) {
        return res.status(400).json({ message: 'Percentage must be between 1 and 10' });
    }
    
    ventas.forEach(venta => {
        venta.value *= (1 - (percentage / 100));
    });
    
    res.json({ message: 'Values updated', ventas });
});
//8.	Crear en node el método para eliminar una factura.
app.delete('/ventas/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const initialLength = ventas.length;
    ventas = ventas.filter(element => element.id !== id);
    if (ventas.length < initialLength) {
        res.json({ message: 'Invoice deleted' });
    } else {
        res.status(404).json({ message: 'Invoice not found' });
    }
});


app.listen(PORT, () => {
    console.log(`Servidor escuchando en http://${host}:${PORT}`); 
});

