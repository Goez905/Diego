// Verificar que el servidor está trabajando de manera correcta
const Server = require('./models/server');

// Instanciar la clase
const server = new Server();
